/**
 * Nemea Cloudflare Worker
 * - Serves static App-Assets (Same-Origin)
 * - Same-Origin-Streaming-Proxy ausschließlich für die vier fest definierten Supertonic-ONNX-Dateien
 * - Fest verdrahtet auf Repository + Revision:
 *   supertone-oss-archive/supertonic-3 @ aafc6e32416a594460b32413efc49d7fe4ce6d46
 * - Redirects werden serverseitig gefolgt
 * - Range-Requests werden korrekt durchgereicht
 * - Response-Body wird gestreamt (kein Puffern im Worker)
 * - Kein offener Proxy
 */

const REVISION = 'aafc6e32416a594460b32413efc49d7fe4ce6d46';
const HF_REPO = 'supertone-oss-archive/supertonic-3';
const UPSTREAM_BASE = `https://huggingface.co/${HF_REPO}/resolve/${REVISION}/`;

// Nur diese vier Dateien sind erlaubt (Pfad relativ zum Repo-Root)
const ALLOWED_ONNX = new Set([
  'onnx/duration_predictor.onnx',
  'onnx/text_encoder.onnx',
  'onnx/vector_estimator.onnx',
  'onnx/vocoder.onnx',
]);

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
  'Access-Control-Allow-Headers': 'Range, Content-Type, Accept, Origin',
  'Access-Control-Expose-Headers': 'Accept-Ranges, Content-Length, Content-Range, Content-Type, ETag',
  'Access-Control-Max-Age': '86400',
};

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // Preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS_HEADERS });
    }

    // ----- Same-Origin Streaming Proxy -----
    if (url.pathname.startsWith('/proxy/')) {
      return handleProxy(request, url);
    }

    // ----- Static Assets (Cloudflare Assets Binding) -----
    // In Wrangler mit [assets] directory = "./public" wird env.ASSETS bereitgestellt.
    if (env.ASSETS) {
      return env.ASSETS.fetch(request);
    }

    // Fallback falls Assets-Binding fehlt (lokaler Test / reiner Worker)
    return new Response(
      'Nemea Worker läuft. Static Assets fehlen (ASSETS Binding). Deploy mit wrangler.toml + public/ Ordner.',
      { status: 200, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }
    );
  },
};

/**
 * Streaming-Proxy nur für die erlaubten ONNX-Dateien.
 * - folgt Redirects (fetch default)
 * - leitet Range weiter
 * - streamt den Body (kein arrayBuffer / kein Puffern)
 */
async function handleProxy(request, url) {
  // /proxy/onnx/vector_estimator.onnx → onnx/vector_estimator.onnx
  const key = url.pathname.slice('/proxy/'.length).replace(/^\/+/, '');

  if (!ALLOWED_ONNX.has(key)) {
    return new Response('Forbidden – only the four fixed Supertonic ONNX files are allowed', {
      status: 403,
      headers: { ...CORS_HEADERS, 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }

  if (request.method !== 'GET' && request.method !== 'HEAD') {
    return new Response('Method Not Allowed', {
      status: 405,
      headers: { ...CORS_HEADERS, Allow: 'GET, HEAD, OPTIONS' },
    });
  }

  const upstreamUrl = UPSTREAM_BASE + key;

  // Eingehende Header selektiv weiterreichen
  const upstreamHeaders = new Headers();
  const range = request.headers.get('Range');
  if (range) {
    upstreamHeaders.set('Range', range);
  }
  // Kein Cookie / Authorization – öffentlich
  upstreamHeaders.set('User-Agent', 'Nemea-Proxy/1.0 (Cloudflare Worker; same-origin stream)');
  upstreamHeaders.set('Accept', '*/*');

  let upstream;
  try {
    upstream = await fetch(upstreamUrl, {
      method: request.method,
      headers: upstreamHeaders,
      redirect: 'follow', // Redirects korrekt behandeln
      cf: {
        // Optional: Cache am Edge für wiederholte Downloads
        cacheTtl: 86400 * 7,
        cacheEverything: true,
      },
    });
  } catch (err) {
    return new Response('Upstream fetch failed: ' + (err && err.message ? err.message : String(err)), {
      status: 502,
      headers: { ...CORS_HEADERS, 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }

  // Antwort-Header aufbauen – Body wird direkt durchgereicht (Stream)
  const outHeaders = new Headers(CORS_HEADERS);

  // Wichtige Header vom Upstream übernehmen
  const passHeaders = [
    'Content-Type',
    'Content-Length',
    'Content-Range',
    'Accept-Ranges',
    'ETag',
    'Last-Modified',
    'Cache-Control',
  ];
  for (const h of passHeaders) {
    const v = upstream.headers.get(h);
    if (v) outHeaders.set(h, v);
  }

  // Fallback Content-Type
  if (!outHeaders.has('Content-Type')) {
    outHeaders.set('Content-Type', 'application/octet-stream');
  }
  if (!outHeaders.has('Accept-Ranges')) {
    outHeaders.set('Accept-Ranges', 'bytes');
  }

  // Cache-Control für große Modelle
  if (!outHeaders.has('Cache-Control')) {
    outHeaders.set('Cache-Control', 'public, max-age=604800, immutable');
  }

  // Streaming: Body nicht materialisieren
  return new Response(upstream.body, {
    status: upstream.status,
    statusText: upstream.statusText,
    headers: outHeaders,
  });
}
