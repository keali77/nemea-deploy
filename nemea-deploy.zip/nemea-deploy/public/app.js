const $=id=>document.getElementById(id);
const input=$("textInput"), rate=$("rate");
let utterance=null, saved=[];
const DB_KEY="stimmen_reader_library_v1";
const profiles=[
 {id:"lola",label:"Lola",purpose:"Meditation",provider:"elevenlabs",voiceId:""},
 {id:"nemea",label:"Nemea",purpose:"Erzählung",provider:"elevenlabs",voiceId:""},
 {id:"klar",label:"Klar",purpose:"Sachtext",provider:"pending",voiceId:""},
 {id:"warm",label:"Warm",purpose:"Hörbuch",provider:"pending",voiceId:""}
];
// Stable interface for later voice integration. No secret/API key is stored in the app.
const SpeechEngine={
 async speak(text,opts={}){
   if(!("speechSynthesis" in window)) throw new Error("Sprachausgabe wird von diesem Browser nicht unterstützt.");
   window.speechSynthesis.cancel();
   const u=new SpeechSynthesisUtterance(text); u.lang="de-DE"; u.rate=Number(opts.rate||1);
   const voices=window.speechSynthesis.getVoices();
   const german=voices.find(v=>v.lang?.toLowerCase().startsWith("de"));
   if(german)u.voice=german;
   u.onend=u.onerror=()=>{if(utterance===u&&opts.onend)opts.onend()};
   utterance=u; window.speechSynthesis.speak(u);
   return u;
 },
 pause(){window.speechSynthesis.pause()},
 resume(){window.speechSynthesis.resume()},
 stop(){window.speechSynthesis.cancel()}
};
// Future hosted provider adapter: app calls own backend; API secrets stay server-side.
async function requestHostedSpeech(text,profileId,options={}){
  const endpoint=localStorage.getItem("tts_backend_url");
  if(!endpoint) throw new Error("Noch kein Stimmen-Backend eingerichtet.");
  const response=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text,profileId,rate:options.rate||1})});
  if(!response.ok) throw new Error("Sprachausgabe fehlgeschlagen ("+response.status+").");
  return await response.blob();
}
function countWords(t){const n=t.trim()?t.trim().split(/\s+/).length:0;$("wordCount").textContent=n+" Wörter";}
input.addEventListener("input",()=>countWords(input.value));
$("rate").addEventListener("input",()=> $("rateValue").textContent=Number(rate.value).toFixed(2).replace(".",",")+"×");
$("clearBtn").onclick=()=>{input.value="";countWords("");input.focus()};
$("sampleBtn").onclick=()=>{input.value="Manchmal beginnt Ruhe nicht damit, dass alles still wird. Sie beginnt in dem Moment, in dem wir uns erlauben, einen Atemzug lang nichts leisten zu müssen. Wir dürfen ankommen. Hier. In diesem Augenblick.";countWords(input.value)};
$("fileInput").onchange=async e=>{const f=e.target.files?.[0];if(!f)return;input.value=await f.text();countWords(input.value);e.target.value=""};
function load(){try{saved=JSON.parse(localStorage.getItem(DB_KEY)||"[]")}catch{saved=[]}renderLibrary()}
function persist(){localStorage.setItem(DB_KEY,JSON.stringify(saved));renderLibrary()}
$("saveBtn").onclick=()=>{const text=input.value.trim();if(!text){alert("Bitte zuerst einen Text eingeben.");return}saved.unshift({id:Date.now(),title:text.split(/\n/)[0].slice(0,64)||"Neuer Text",text,created:new Date().toLocaleDateString("de-AT")});persist();$("engineStatus").textContent="Gespeichert"};
function renderLibrary(){$("libraryCount").textContent=saved.length;$("libraryList").innerHTML="";if(!saved.length){$("libraryList").innerHTML='<div class="empty">Noch keine gespeicherten Texte.<br>Speichere oben deinen ersten Text.</div>';return}saved.forEach(item=>{const row=document.createElement("div");row.className="library-item";const main=document.createElement("div");main.className="item-main";const title=document.createElement("strong");title.textContent=item.title;const meta=document.createElement("span");meta.textContent=item.created+" · "+item.text.trim().split(/\s+/).length+" Wörter";main.append(title,meta);const open=document.createElement("button");open.textContent="Öffnen";open.onclick=()=>{input.value=item.text;countWords(input.value);window.scrollTo({top:0,behavior:"smooth"})};const del=document.createElement("button");del.textContent="✕";del.setAttribute("aria-label","Text löschen");del.onclick=()=>{saved=saved.filter(x=>x.id!==item.id);persist()};row.append(main,open,del);$("libraryList").append(row)})}
/* ===== Lokale Stimme: Supertonic 3 (ONNX Runtime Web, WASM) ===== */
const audioEl=$("localAudio"), engineSel=$("engineSelect"), stepsSel=$("stepsSelect"), baseInput=$("baseInput");
const LS_ENGINE="nemea_engine", LS_STEPS="nemea_steps", LS_BASE="nemea_model_base";
const store={get:k=>{try{return localStorage.getItem(k)}catch{return null}},set:(k,v)=>{try{v==null?localStorage.removeItem(k):localStorage.setItem(k,v)}catch{}}};
const baseUrl=()=>{let u=(baseInput.value.trim()||Supertonic.DEFAULT_BASE);if(u&&!/\/$/.test(u))u+='/';return u;};
let active=null, wakeLock=null; // active: "system" | "local" | null
const setStatus=t=>{$("engineStatus").textContent=t};
const hint=t=>{$("playHint").textContent=t};
function idleUI(label){active=null;setStatus(label||"Bereit");$("pauseBtn").disabled=true;$("stopBtn").disabled=true;$("pauseBtn").textContent="Ⅱ Pause";releaseWake()}
function runningUI(){$("pauseBtn").disabled=false;$("stopBtn").disabled=false;$("pauseBtn").textContent="Ⅱ Pause"}
async function takeWake(){try{if(navigator.wakeLock)wakeLock=await navigator.wakeLock.request("screen")}catch{}}
function releaseWake(){try{wakeLock&&wakeLock.release()}catch{}wakeLock=null}

const Local={
  run:null,
  // Muss synchron im Tipp-Ereignis laufen: schaltet das Audio-Element für spätere, programmatische Wiedergabe frei.
  prime(){try{const u=URL.createObjectURL(Supertonic.wavBlob(new Float32Array(2205),44100));audioEl.src=u;audioEl.play().catch(()=>{});setTimeout(()=>URL.revokeObjectURL(u),4000)}catch{}},
  start(text,o){
    this.stop();
    const chunks=Supertonic.planChunks(text);
    if(!chunks.length)throw new Error("Im Text wurde nichts Sprechbares gefunden.");
    const run=this.run={chunks,gen:0,play:0,urls:[],cur:null,waiting:false,paused:false,cancelled:false,error:null,steps:o.steps,speed:o.rate,unknown:new Set(),wake:null};
    run.waiting=true; // Wiedergabe startet, sobald der erste Abschnitt fertig ist
    active="local";runningUI();setStatus("Erzeuge 1/"+chunks.length);takeWake();this.meta();
    this.pump(run);
  },
  async pump(run){
    const sr=Supertonic.sampleRate(),n=run.chunks.length;
    try{
      while(!run.cancelled&&run.gen<n){
        while(!run.cancelled&&run.urls.length-run.play>=2)await new Promise(r=>{run.wake=r});
        if(run.cancelled)return;
        if(run.play>=run.urls.length&&!run.paused)setStatus("Erzeuge "+(run.gen+1)+"/"+n);
        const w=await Supertonic.synth(run.chunks[run.gen],{voice:"F1",steps:run.steps,speed:run.speed,onUnknown:u=>u.forEach(c=>run.unknown.add(c))});
        if(run.cancelled)return;
        run.urls.push(URL.createObjectURL(Supertonic.wavBlob(Supertonic.finalizeChunk(w,sr),sr)));run.gen++;
        if(run.waiting){run.waiting=false;this.next(run)}
      }
    }catch(e){if(!run.cancelled){run.error=e;if(run.waiting||run.play>=run.urls.length)this.next(run)}}
  },
  next(run){
    if(run.cancelled)return;
    const n=run.chunks.length;
    if(run.play<run.urls.length){
      run.cur=run.urls[run.play];run.waiting=false;audioEl.src=run.cur;setStatus((run.paused?"Pausiert ":"Liest vor ")+(run.play+1)+"/"+n);
      if(!run.paused)audioEl.play().catch(()=>this.fail(run,new Error("Die Wiedergabe wurde vom Browser blockiert. Bitte erneut auf „Vorlesen“ tippen.")));
      this.wakeGen(run);
    }else if(run.error||run.gen>=n)this.finish(run);
    else{run.waiting=true;setStatus("Erzeuge "+(run.gen+1)+"/"+n+" …")}
  },
  wakeGen(run){if(run.wake){const w=run.wake;run.wake=null;w()}},
  ended(){
    const run=this.run;if(!run||!run.cur||audioEl.src!==run.cur)return;
    URL.revokeObjectURL(run.cur);run.cur=null;run.play++;this.wakeGen(run);this.next(run);
  },
  finish(run){
    const err=run.error,unk=[...run.unknown];this.stop();
    if(err){hint(err.message||String(err));idleUI("Fehler")}
    else{idleUI("Fertig");hint(unk.length?"Fertig. Nicht sprechbare Zeichen wurden übersprungen: "+unk.join(" "):"Fertig.")}
  },
  fail(run,e){if(this.run!==run)return;run.error=e;this.finish(run)},
  pause(){const r=this.run;if(!r)return;r.paused=true;audioEl.pause();setStatus("Pausiert");$("pauseBtn").textContent="▶ Weiter"},
  resume(){const r=this.run;if(!r)return;r.paused=false;$("pauseBtn").textContent="Ⅱ Pause";
    if(r.cur&&audioEl.src===r.cur){setStatus("Liest vor "+(r.play+1)+"/"+r.chunks.length);audioEl.play().catch(()=>this.fail(r,new Error("Die Wiedergabe wurde vom Browser blockiert. Bitte erneut auf „Vorlesen“ tippen.")))}
    else if(!r.waiting&&r.play<r.urls.length)this.next(r)},
  stop(){
    const r=this.run;if(!r)return;
    r.cancelled=true;this.run=null;audioEl.pause();audioEl.removeAttribute("src");try{audioEl.load()}catch{}
    r.urls.forEach(u=>URL.revokeObjectURL(u));this.wakeGen(r);
  },
  meta(){
    if(!("mediaSession" in navigator))return;
    try{navigator.mediaSession.metadata=new MediaMetadata({title:"Nemea – Vorlesen",artist:"Supertonic 3 · F1 (lokal)"});
    navigator.mediaSession.setActionHandler("play",()=>this.resume());
    navigator.mediaSession.setActionHandler("pause",()=>this.pause());
    navigator.mediaSession.setActionHandler("stop",()=>{this.stop();idleUI()})}catch{}
  }
};
audioEl.addEventListener("ended",()=>Local.ended());
audioEl.addEventListener("error",()=>{const r=Local.run;if(r&&r.cur&&audioEl.src===r.cur)Local.fail(r,new Error("Ein erzeugter Audio-Abschnitt konnte nicht abgespielt werden."))});

function stopAll(){
  if(active==="system"){SpeechEngine.stop()}
  Local.stop();idleUI();
}

/* --- Modell-Laden und Statusanzeige --- */
let loadingModels=false;
async function refreshModelState(){
  const box=$("modelBox");box.hidden=engineSel.value!=="supertonic";
  if(box.hidden)return;
  const sup=Supertonic.support();
  if(!sup.ok){$("modelState").textContent="Nicht möglich";$("modelDetail").textContent=sup.reason;$("modelDetail").className="hint error";$("modelLoadBtn").disabled=true;return}
  $("modelLoadBtn").disabled=loadingModels;
  if(Supertonic.isReady()){$("modelState").textContent="Bereit (lokal, WASM)";$("modelLoadBtn").hidden=true;return}
  $("modelLoadBtn").hidden=false;
  try{
    const info=await Supertonic.cacheInfo(baseUrl());
    if(info.allCached){$("modelState").textContent="Auf dem Gerät gespeichert";$("modelLoadBtn").textContent="Modelle starten"}
    else{const mb=Math.round((info.totalBytes-info.cachedBytes)/1048576);$("modelState").textContent="Noch nicht geladen (ca. "+mb+" MB)";$("modelLoadBtn").textContent="Modelle laden (ca. "+mb+" MB)"}
  }catch{$("modelState").textContent="Status unbekannt"}
}
async function loadModels(){
  if(loadingModels||Supertonic.isReady())return;
  loadingModels=true;$("modelLoadBtn").disabled=true;$("playBtn").disabled=true;
  const pg=$("modelProgress"),det=$("modelDetail");pg.hidden=false;pg.removeAttribute("value");det.className="hint";det.textContent="";
  setStatus("Lade Modelle …");takeWake();
  try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch{}
  try{
    await Supertonic.load({baseUrl:baseUrl(),onProgress:p=>{
      if(p.fraction==null)pg.removeAttribute("value");else pg.value=p.fraction;
      det.textContent=p.text;
    }});
    det.textContent="Modelle geladen. Hinweis: Offline-Start ist damit noch nicht bewiesen.";
    hint("Modelle bereit. Tippe auf „Vorlesen“.");
    setStatus("Bereit");
  }catch(e){
    det.className="hint error";det.textContent=e.message||String(e);setStatus("Fehler");
  }finally{
    loadingModels=false;pg.hidden=true;$("playBtn").disabled=false;releaseWake();refreshModelState();updateStorageInfo();
  }
}
async function updateStorageInfo(){
  try{const e=await navigator.storage.estimate();$("storageInfo").textContent="Belegt: ca. "+Math.round(e.usage/1048576)+" MB von ca. "+Math.round(e.quota/1048576)+" MB (Schätzung des Browsers). Ob Safari die Dateien dauerhaft behält, ist nicht garantiert."}catch{$("storageInfo").textContent="Speicherangabe nicht verfügbar."}
}

engineSel.onchange=()=>{store.set(LS_ENGINE,engineSel.value);stopAll();refreshModelState();
  hint(engineSel.value==="supertonic"?"Supertonic läuft lokal auf dem Gerät. Beim ersten Mal ist ein Download nötig.":"iPhone-Systemstimme (Funktionstest).")};
stepsSel.onchange=()=>store.set(LS_STEPS,stepsSel.value);
baseInput.onchange=()=>{store.set(LS_BASE,baseInput.value.trim()||null);refreshModelState()};
$("baseReset").onclick=()=>{baseInput.value=Supertonic.DEFAULT_BASE;store.set(LS_BASE,null);refreshModelState()};
$("modelLoadBtn").onclick=loadModels;
$("clearModelsBtn").onclick=async()=>{
  if(!confirm("Gespeicherte Sprachmodelle (ca. 380 MB) vom Gerät löschen? Zum erneuten Nutzen ist wieder ein Download nötig."))return;
  stopAll();await Supertonic.clearCache();await refreshModelState();updateStorageInfo();
};

/* --- Bedienung --- */
$("playBtn").onclick=async()=>{
  const text=input.value.trim();
  if(!text){hint("Bitte zuerst einen Text eingeben.");return}
  stopAll();
  if(engineSel.value!=="supertonic"){
    try{await SpeechEngine.speak(text,{rate:rate.value,onend:()=>idleUI("Fertig")});active="system";setStatus("Liest vor");runningUI();hint("iPhone-Systemstimme aktiv.")}catch(e){hint(e.message)}
    return;
  }
  Local.prime();
  try{
    if(!Supertonic.isReady()){
      const info=await Supertonic.cacheInfo(baseUrl());
      if(!info.allCached){hint("Die Supertonic-Modelle sind noch nicht auf dem Gerät. Bitte zuerst „Modelle laden“ tippen (WLAN empfohlen).");return}
      await loadModels();
      if(!Supertonic.isReady()){hint("Die Modelle konnten nicht gestartet werden. Details stehen im Modell-Bereich.");return}
    }
    hint("Supertonic 3 · F1 (lokal). Die ersten Sekunden Rechenzeit sind noch nicht gemessen.");
    Local.start(text,{rate:Number(rate.value),steps:Number(stepsSel.value)});
  }catch(e){hint(e.message||String(e));idleUI("Fehler")}
};
$("pauseBtn").onclick=()=>{
  if(active==="local"){const r=Local.run;if(r&&r.paused)Local.resume();else Local.pause();return}
  if(window.speechSynthesis.paused){SpeechEngine.resume();$("pauseBtn").textContent="Ⅱ Pause"}else{SpeechEngine.pause();$("pauseBtn").textContent="▶ Weiter"}
};
$("stopBtn").onclick=()=>stopAll();
$("settingsBtn").onclick=()=>{updateStorageInfo();$("settingsDialog").showModal()};
$("closeSettings").onclick=()=>$("settingsDialog").close();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
load();countWords("");
baseInput.value=store.get(LS_BASE)||Supertonic.DEFAULT_BASE;
stepsSel.value=store.get(LS_STEPS)||"8";
engineSel.value=store.get(LS_ENGINE)==="supertonic"?"supertonic":"system";
refreshModelState();
if(Supertonic.lastLoadCrashed()){$("modelBox").hidden=false;$("modelDetail").className="hint error";$("modelDetail").textContent="Der letzte Ladeversuch wurde nicht beendet, vermutlich wegen zu wenig Arbeitsspeicher. Andere Apps schließen, Seite neu laden und erneut versuchen."}
