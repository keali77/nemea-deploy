/*
 * Supertonic 3 – lokale Sprachausgabe für Nemea (ONNX Runtime Web, nur WASM/CPU).
 * Pipeline und Tensor-Schnittstellen: aus nemea-tts-test-v2 übernommen und gegen
 * Nemea-ONNX-Pruefbericht.txt, tts.json, F1.json und unicode_indexer.json geprüft.
 * Kein WebGPU, keine Cloud, keine API-Schlüssel.
 */
(function (root) {
  'use strict';

  var ORT_BASE = 'https://cdn.jsdelivr.net/npm/onnxruntime-web@1.20.1/dist/';
  // Same-Origin-Streaming-Proxy (Cloudflare Worker). Nur die vier fest definierten ONNX-Dateien.
  // Upstream fest auf geprüfte Revision: supertone-oss-archive/supertonic-3 @ aafc6e32416a594460b32413efc49d7fe4ce6d46
  var DEFAULT_BASE = (typeof root.location !== 'undefined' && root.location.origin)
    ? (root.location.origin + '/proxy/')
    : '/proxy/';
  var FALLBACK_BASE = DEFAULT_BASE;
  // Kein offener Proxy und keine externen HF-URLs mehr für ONNX – ausschließlich Same-Origin.
  var HF_BASES = [DEFAULT_BASE];
  var CACHE_NAME = 'nemea-st3-models-v1';
  var MANIFEST_KEY = 'https://nemea.local/model-manifest.json';
  var LOCK_KEY = 'nemea-st3-lock';
  var VOICES = ['F1'];

  // json/voice: lokal mit der App ausgeliefert (kein Cross-Origin).
  // onnx: über den Same-Origin-Proxy des Workers (Streaming, Range, Redirects).
  var FILES = [
    { path: 'onnx/tts.json', size: 8253, kind: 'json', local: true },
    { path: 'onnx/unicode_indexer.json', size: 277676, kind: 'json', local: true },
    { path: 'onnx/vector_estimator.onnx', size: 256534781, kind: 'onnx', name: 'vector_estimator' },
    { path: 'onnx/vocoder.onnx', size: 101424195, kind: 'onnx', name: 'vocoder' },
    { path: 'onnx/text_encoder.onnx', size: 36416150, kind: 'onnx', name: 'text_encoder' },
    { path: 'onnx/duration_predictor.onnx', size: 3700147, kind: 'onnx', name: 'duration_predictor' },
    { path: 'voice_styles/F1.json', size: 292046, kind: 'voice', name: 'F1', local: true }
  ];

  // Schnittstellen laut Nemea-ONNX-Pruefbericht.txt
  var CONTRACT = {
    duration_predictor: { inp: ['text_ids', 'style_dp', 'text_mask'], out: ['duration'] },
    text_encoder: { inp: ['text_ids', 'style_ttl', 'text_mask'], out: ['text_emb'] },
    vector_estimator: { inp: ['noisy_latent', 'text_emb', 'style_ttl', 'latent_mask', 'text_mask', 'current_step', 'total_step'], out: ['denoised_latent'] },
    vocoder: { inp: ['latent'], out: ['wav_tts'] }
  };
  var DIMS = { style_ttl: [1, 50, 256], style_dp: [1, 8, 16] };
  var LATENT_CHANNELS = 144;

  function STError(code, message, cause) {
    var e = new Error(message);
    e.name = 'STError'; e.code = code; e.cause = cause;
    return e;
  }

  function ls(k, v) {
    try { if (v === undefined) return root.localStorage.getItem(k); if (v === null) root.localStorage.removeItem(k); else root.localStorage.setItem(k, v); } catch (_) { }
    return null;
  }

  var S = null, loading = null, queue = Promise.resolve();

  /* ---------- Text ---------- */
  function prep(t, unk) {
    t = t.normalize('NFKD').replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]+/gu, '');
    var R = { '–': '-', '‑': '-', '—': '-', '_': ' ', '\u201C': '"', '\u201D': '"', '\u201E': '"', '\u00AB': '"', '\u00BB': '"', '\u2018': "'", '\u2019': "'", '\u201A': "'", '´': "'", '`': "'", '[': ' ', ']': ' ', '|': ' ', '/': ' ', '#': ' ', '→': ' ', '←': ' ' };
    for (var k in R) t = t.split(k).join(R[k]);
    t = t.replace(/[♥☆♡©\\]/g, '').replace(/ ,/g, ',').replace(/ \./g, '.').replace(/ !/g, '!').replace(/ \?/g, '?').replace(/ ;/g, ';').replace(/ :/g, ':').replace(/ '/g, "'");
    t = t.replace(/\s+/g, ' ').trim();
    if (!/[.!?;:,'")\]}…]$/.test(t)) t += '.';
    return '<de>' + t + '</de>';
  }

  var SPLIT;
  try { SPLIT = new RegExp('(?<!Dr\\.|Prof\\.|z\\. B\\.|ca\\.|Nr\\.|etc\\.|bzw\\.|usw\\.)(?<!\\b[A-Z]\\.)(?<=[.!?])\\s+'); } catch (_) { SPLIT = null; }
  function sentences(p) { return SPLIT ? p.split(SPLIT) : p.replace(/([.!?])\s+/g, '$1\u0001').split('\u0001'); }

  // Zu lange Sätze an Kommas/Semikolons/Doppelpunkten, sonst an Leerzeichen teilen.
  function splitLong(s, max) {
    if (s.length <= max) return [s];
    var pieces = s.replace(/([,;:])\s+/g, '$1\u0001').split('\u0001'), out = [], cur = '';
    function push(x) { if (cur && cur.length + 1 + x.length > max) { out.push(cur); cur = ''; } cur = cur ? cur + ' ' + x : x; }
    pieces.forEach(function (p) {
      if (p.length <= max) { push(p); return; }
      p.split(/\s+/).forEach(function (w) {
        while (w.length > max) { push(w.slice(0, max)); w = w.slice(max); }
        push(w);
      });
    });
    if (cur) out.push(cur);
    return out;
  }

  function chunk(text, max) {
    max = max || 300; var out = [];
    text.trim().split(/\n\s*\n+/).forEach(function (p) {
      p = p.trim(); if (!p) return;
      var cur = '';
      sentences(p).forEach(function (s0) {
        splitLong(s0, max).forEach(function (s) {
          if (cur.length + s.length + 1 <= max) cur += (cur ? ' ' : '') + s;
          else { if (cur) out.push(cur); cur = s; }
        });
      });
      if (cur) out.push(cur);
    });
    return out;
  }

  var SPEAKABLE;
  try { SPEAKABLE = new RegExp('[\\p{L}\\p{N}]', 'u'); } catch (_) { SPEAKABLE = /[A-Za-z0-9\u00C0-\u024F]/; }

  // Kurzer erster Abschnitt, damit die Wiedergabe früh beginnt.
  function planChunks(text, o) {
    o = o || {};
    var max = o.max || 260, first = o.first || 140, all = chunk(text, max);
    if (all.length && all[0].length > first) { var parts = chunk(all[0], first); all.splice.apply(all, [0, 1].concat(parts)); }
    return all.filter(function (c) { return SPEAKABLE.test(c); });
  }

  /* ---------- Audio ---------- */
  function finalizeChunk(w, sr, gapSec) {
    var fade = Math.min(Math.floor(sr * 0.005), Math.floor(w.length / 2)), gap = Math.floor((gapSec == null ? 0.25 : gapSec) * sr);
    var out = new Float32Array(w.length + gap); out.set(w);
    for (var i = 0; i < fade; i++) { var g = i / fade; out[i] *= g; out[w.length - 1 - i] *= g; }
    return out;
  }
  function wavBlob(f, sr) {
    var b = new ArrayBuffer(44 + f.length * 2), d = new DataView(b);
    function w(o, s) { for (var i = 0; i < s.length; i++) d.setUint8(o + i, s.charCodeAt(i)); }
    w(0, 'RIFF'); d.setUint32(4, 36 + f.length * 2, true); w(8, 'WAVEfmt '); d.setUint32(16, 16, true); d.setUint16(20, 1, true); d.setUint16(22, 1, true);
    d.setUint32(24, sr, true); d.setUint32(28, sr * 2, true); d.setUint16(32, 2, true); d.setUint16(34, 16, true); w(36, 'data'); d.setUint32(40, f.length * 2, true);
    for (var i = 0; i < f.length; i++) d.setInt16(44 + i * 2, Math.max(-1, Math.min(1, f[i])) * 32767, true);
    return new Blob([b], { type: 'audio/wav' });
  }

  /* ---------- Cache ---------- */
  function fileUrl(base, f) { return base + f.path; }
  function localUrl(f) {
    try { return new URL(f.path, root.location.href).href; } catch (_) { return './' + f.path; }
  }
  function isSafari() {
    var ua = (root.navigator && root.navigator.userAgent) || '';
    return /AppleWebKit/i.test(ua) && /Mobile/i.test(ua) && !/CriOS|FxiOS|EdgiOS/i.test(ua);
  }
  async function readManifest(c) {
    var r = await c.match(MANIFEST_KEY); if (!r) return {};
    try { return await r.json(); } catch (_) { return {}; }
  }
  async function writeManifest(c, m) {
    await c.put(MANIFEST_KEY, new Response(JSON.stringify(m), { headers: { 'Content-Type': 'application/json' } }));
  }
  async function isCached(c, m, url, f) { return m[url] === f.size && !!(await c.match(url)); }

  async function cacheInfo(base) {
    base = base || DEFAULT_BASE;
    if (!root.caches) return { supported: false, allCached: false, cachedBytes: 0, totalBytes: 0, files: [] };
    var files = [], cachedBytes = 0, totalBytes = 0, none = !(await root.caches.has(CACHE_NAME));
    if (none) {
      FILES.forEach(function (f) {
        var local = !!f.local;
        files.push({ path: f.path, size: f.size, cached: local });
        totalBytes += f.size; if (local) cachedBytes += f.size;
      });
      return { supported: true, allCached: cachedBytes === totalBytes, cachedBytes: cachedBytes, totalBytes: totalBytes, files: files };
    }
    var c = await root.caches.open(CACHE_NAME), m = await readManifest(c);
    for (var i = 0; i < FILES.length; i++) {
      var f = FILES[i], ok = !!f.local || await isCached(c, m, fileUrl(base, f), f);
      files.push({ path: f.path, size: f.size, cached: ok }); totalBytes += f.size; if (ok) cachedBytes += f.size;
    }
    return { supported: true, allCached: cachedBytes === totalBytes, cachedBytes: cachedBytes, totalBytes: totalBytes, files: files };
  }

  function mapNetError(e, label, url) {
    if (e && e.name === 'STError') return e;
    if (e && (e.name === 'QuotaExceededError' || /quota/i.test(e.message || '')))
      return STError('quota', 'Nicht genug Speicherplatz auf dem Gerät für die Sprachmodelle (ca. 380 MB). Bitte Speicher freigeben und erneut versuchen.', e);
    var detail = (e && e.message) ? String(e.message).slice(0, 160) : '';
    if (e instanceof TypeError || (e && /network|fetch|load failed|failed to fetch/i.test(e.message || '')))
      return STError('netz', label + ' – Laden fehlgeschlagen' + (detail ? ' (' + detail + ')' : '') + (url ? ' · URL: ' + url : '') + '. Internet/VPN prüfen; bei ONNX ggf. später erneut versuchen.', e);
    return STError('speichern', label + ' konnte nicht gespeichert werden: ' + (detail || e), e);
  }

  async function fetchBinary(url, onFileBytes) {
    var res;
    try {
      res = await root.fetch(url, { mode: 'cors', redirect: 'follow', credentials: 'omit', cache: 'no-store' });
    } catch (e) {
      throw mapNetError(e, url.split('/').pop(), url);
    }
    if (!res.ok) throw STError('http', 'HTTP ' + res.status + ' bei ' + url.split('/').pop() + ' · ' + url, null);
    // Immer als ArrayBuffer lesen (Safari-sicher, kein Stream-Cache-Problem).
    var ab = await res.arrayBuffer();
    var got = ab.byteLength;
    if (onFileBytes) onFileBytes(got);
    return ab;
  }

  async function downloadRemoteOnnx(c, cacheKey, f, onFileBytes) {
    var label = f.path.split('/').pop();
    var bases = HF_BASES.slice();
    var lastErr = null;
    for (var i = 0; i < bases.length; i++) {
      var tryUrl = bases[i] + f.path;
      try {
        if (onFileBytes) onFileBytes(0);
        var ab = await fetchBinary(tryUrl, onFileBytes);
        if (ab.byteLength !== f.size) {
          lastErr = STError('groesse', label + ' unvollständig (' + ab.byteLength + ' statt ' + f.size + ' Bytes) von ' + tryUrl, null);
          continue;
        }
        await c.put(cacheKey, new Response(ab, { status: 200, headers: { 'Content-Type': 'application/octet-stream', 'Content-Length': String(ab.byteLength) } }));
        return ab.byteLength;
      } catch (e) {
        lastErr = e;
      }
    }
    throw (lastErr && lastErr.name === 'STError') ? lastErr : mapNetError(lastErr, label, bases[0] + f.path);
  }

  async function ensureFile(c, base, f, onFileBytes) {
    // Lokale App-Assets: direkt von der Pages-Origin laden (kein Hugging Face).
    if (f.local) {
      var lu = localUrl(f);
      try {
        var res = await root.fetch(lu, { cache: 'force-cache' });
        if (!res.ok) throw STError('http', 'Lokale Datei ' + f.path + ' fehlt im Deploy (HTTP ' + res.status + '). Bitte ZIP vollständig hochladen.', null);
        return res;
      } catch (e) {
        if (e && e.name === 'STError') throw e;
        throw STError('netz', 'Lokale Datei ' + f.path + ' nicht lesbar. Cloudflare-Deploy prüfen (Ordner onnx/ und voice_styles/).', e);
      }
    }
    var url = fileUrl(base || DEFAULT_BASE, f), m = await readManifest(c);
    if (!(await isCached(c, m, url, f))) {
      try { await c.delete(url); } catch (_) { }
      await downloadRemoteOnnx(c, url, f, onFileBytes || function () { });
      m = await readManifest(c); m[url] = f.size; await writeManifest(c, m);
    }
    var r = await c.match(url);
    if (!r) throw STError('speichern', f.path + ' liegt nach dem Laden nicht im Speicher (Speicher voll?).', null);
    return r;
  }

  /* ---------- ORT ---------- */
  function loadScript(src) {
    return new Promise(function (ok, no) {
      var s = root.document.createElement('script'); s.src = src; s.crossOrigin = 'anonymous'; s.onload = ok;
      s.onerror = function () { no(STError('ort', 'Die Laufzeitbibliothek (onnxruntime-web) konnte nicht geladen werden. Beim ersten Start ist Internet nötig; danach liegt sie im Cache.', null)); };
      root.document.head.appendChild(s);
    });
  }

  function sameSet(a, b) { return a.length === b.length && a.every(function (x) { return b.indexOf(x) >= 0; }); }

  async function releaseAll(ses) { for (var k in ses) { try { await ses[k].release(); } catch (_) { } } }

  /* ---------- Laden ---------- */
  function support() {
    if (typeof root.WebAssembly === 'undefined') return { ok: false, reason: 'Dieser Browser unterstützt WebAssembly nicht.' };
    if (!root.caches) return { ok: false, reason: 'Der Browser-Speicher (Cache Storage) ist nicht verfügbar. In Safari ggf. nur über HTTPS oder als Home-Bildschirm-App.' };
    return { ok: true, reason: '' };
  }

  async function doLoad(opts) {
    var base = opts.baseUrl || DEFAULT_BASE, progress = opts.onProgress || function () { }, sup = support();
    if (!sup.ok) throw STError('unsupported', sup.reason, null);
    if (!/\/$/.test(base)) base += '/';
    var t0 = Date.now();
    ls(LOCK_KEY, String(Date.now()));
    var ses = {};
    try {
      if (!root.ort) await loadScript(ORT_BASE + 'ort.min.js');
      var ort = root.ort;
      ort.env.wasm.wasmPaths = ORT_BASE; ort.env.wasm.numThreads = 1;
      var sopt = { executionProviders: ['wasm'], graphOptimizationLevel: 'basic', enableMemPattern: false, enableCpuMemArena: false };
      var c = await root.caches.open(CACHE_NAME), m = await readManifest(c), toLoad = 0, done = 0;
      for (var i = 0; i < FILES.length; i++) {
        var fi = FILES[i];
        if (fi.local) continue;
        if (!(await isCached(c, m, fileUrl(base, fi), fi))) toLoad += fi.size;
      }
      var needDownload = toLoad > 0;
      function report(text, cur) {
        progress({ text: text, fraction: needDownload ? Math.min(1, (done + (cur || 0)) / toLoad) : null, downloading: needDownload });
      }
      async function get(f) {
        if (f.local) {
          report('Lese ' + f.path.split('/').pop() + ' (lokal) …', 0);
          return ensureFile(c, base, f);
        }
        var url = fileUrl(base, f), was = await isCached(c, await readManifest(c), url, f);
        var r = await ensureFile(c, base, f, function (got) { report('Lade ' + f.path.split('/').pop() + ' – ' + (((done + got) / 1048576) | 0) + ' von ' + ((toLoad / 1048576) | 0) + ' MB', got); });
        if (!was) done += f.size;
        return r;
      }
      var cfg = await (await get(FILES[0])).json(), idx = await (await get(FILES[1])).json();
      if (!Array.isArray(idx)) throw STError('format', 'unicode_indexer.json hat nicht das erwartete Format (Liste).', null);
      var ld = cfg.ttl.latent_dim * cfg.ttl.chunk_compress_factor;
      if (ld !== LATENT_CHANNELS) throw STError('format', 'tts.json passt nicht zu den Modellen (Latent-Kanäle ' + ld + ' statt ' + LATENT_CHANNELS + ').', null);

      var order = FILES.filter(function (f) { return f.kind === 'onnx'; }), n = 0;
      for (var j = 0; j < order.length; j++) {
        var f = order[j], r = await get(f);
        report('Lese ' + f.name + ' …');
        var buf = await r.arrayBuffer();
        progress({ text: 'Initialisiere ' + f.name + ' (' + (++n) + ' von ' + order.length + ') …', fraction: needDownload ? null : n / order.length, downloading: false });
        try { ses[f.name] = await ort.InferenceSession.create(new Uint8Array(buf), sopt); }
        catch (e) { throw STError('init', 'Das Modell ' + f.name + ' konnte nicht gestartet werden. Mögliche Ursachen: zu wenig Arbeitsspeicher auf dem iPhone oder nicht unterstützte Laufzeit. Bitte Seite neu laden, andere Apps schließen und erneut versuchen. (' + ((e && e.message) || e) + ')', e); }
        buf = null; r = null;
        var ct = CONTRACT[f.name], inN = ses[f.name].inputNames, outN = ses[f.name].outputNames;
        if (inN && outN && (!sameSet(inN, ct.inp) || !sameSet(outN, ct.out)))
          throw STError('format', 'Das Modell ' + f.name + ' hat unerwartete Ein-/Ausgänge (' + inN.join(',') + ' → ' + outN.join(',') + ').', null);
      }
      var styles = {};
      function mk(p, key, vname) {
        var want = DIMS[key], total = want.reduce(function (a, b) { return a * b; }, 1);
        var data = Float32Array.from(p.data.flat(Infinity));
        if (!p.dims || p.dims.join() !== want.join() || data.length !== total) throw STError('format', 'Stimmprofil ' + vname + ': ' + key + ' hat nicht die Form [' + want.join(',') + '].', null);
        return new ort.Tensor('float32', data, p.dims);
      }
      for (var k = 0; k < VOICES.length; k++) {
        var vf = FILES.filter(function (x) { return x.kind === 'voice' && x.name === VOICES[k]; })[0], o = await (await get(vf)).json();
        styles[vf.name] = { ttl: mk(o.style_ttl, 'style_ttl', vf.name), dp: mk(o.style_dp, 'style_dp', vf.name) };
      }
      S = { cfg: cfg, idx: idx, ses: ses, styles: styles, loadSeconds: (Date.now() - t0) / 1000, fromNet: needDownload };
      ls(LOCK_KEY, null);
      progress({ text: 'Bereit.', fraction: 1, downloading: false });
      return S;
    } catch (e) {
      ls(LOCK_KEY, null);
      await releaseAll(ses);
      throw (e && e.name === 'STError') ? e : mapNetError(e, 'Modelle');
    }
  }

  function load(opts) {
    if (S) return Promise.resolve(S);
    if (loading) return loading;
    loading = doLoad(opts || {}).finally(function () { loading = null; });
    return loading;
  }

  async function unload() { if (S) { var s = S; S = null; await releaseAll(s.ses); } }
  async function clearCache() { await unload(); if (root.caches) await root.caches.delete(CACHE_NAME); }

  /* ---------- Inferenz ---------- */
  async function infer(text, voice, steps, speed, onUnknown, onStep) {
    var ort = root.ort, cfg = S.cfg, idx = S.idx, ses = S.ses, sty = S.styles[voice];
    if (!sty) throw STError('voice', 'Stimmprofil ' + voice + ' ist nicht geladen.', null);
    var sr = cfg.ae.sample_rate, T = prep(text), a = [], unk = new Set();
    for (var ch of T) { var cp = ch.codePointAt(0), id = cp < idx.length ? idx[cp] : -1; if (id < 0) unk.add(ch); else a.push(BigInt(id)); }
    if (unk.size && onUnknown) onUnknown(unk);
    var L = a.length, tid = new ort.Tensor('int64', BigInt64Array.from(a), [1, L]), tm = new ort.Tensor('float32', new Float32Array(L).fill(1), [1, 1, L]);
    var dp = await ses.duration_predictor.run({ text_ids: tid, style_dp: sty.dp, text_mask: tm });
    var dur = dp.duration.data[0] / speed; if (dp.duration.dispose) dp.duration.dispose();
    var te = await ses.text_encoder.run({ text_ids: tid, style_ttl: sty.ttl, text_mask: tm });
    var cs = cfg.ae.base_chunk_size * cfg.ttl.chunk_compress_factor, ll = Math.ceil(Math.floor(dur * sr) / cs), ld = cfg.ttl.latent_dim * cfg.ttl.chunk_compress_factor;
    var xt = new Float32Array(ld * ll);
    for (var i = 0; i < xt.length; i++) { var u1 = Math.max(1e-4, Math.random()), u2 = Math.random(); xt[i] = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2); }
    var lm = new ort.Tensor('float32', new Float32Array(ll).fill(1), [1, 1, ll]), tot = new ort.Tensor('float32', new Float32Array([steps]), [1]);
    for (var s = 0; s < steps; s++) {
      var o = await ses.vector_estimator.run({ noisy_latent: new ort.Tensor('float32', xt, [1, ld, ll]), text_emb: te.text_emb, style_ttl: sty.ttl, latent_mask: lm, text_mask: tm, current_step: new ort.Tensor('float32', new Float32Array([s]), [1]), total_step: tot });
      xt = o.denoised_latent.data; if (onStep) onStep(s + 1, steps);
      await new Promise(function (r) { setTimeout(r, 0); });
    }
    if (te.text_emb.dispose) te.text_emb.dispose();
    var v = await ses.vocoder.run({ latent: new ort.Tensor('float32', xt, [1, ld, ll]) }); xt = null;
    var w = new Float32Array(v.wav_tts.data); if (v.wav_tts.dispose) v.wav_tts.dispose();
    return w;
  }

  // Ein Text-Abschnitt -> Float32-Audio (44,1 kHz). Aufrufe werden nacheinander abgearbeitet.
  function synth(text, o) {
    o = o || {};
    if (!S) return Promise.reject(STError('nicht_geladen', 'Die Sprachmodelle sind noch nicht geladen.', null));
    var p = queue.then(function () {
      if (!S) throw STError('nicht_geladen', 'Die Sprachmodelle sind nicht mehr geladen.', null);
      return infer(text, o.voice || 'F1', o.steps || 8, o.speed || 1, o.onUnknown, o.onStep);
    });
    queue = p.catch(function () { });
    return p;
  }

  root.Supertonic = {
    VOICES: VOICES, DEFAULT_BASE: DEFAULT_BASE, FALLBACK_BASE: FALLBACK_BASE, HF_BASES: HF_BASES, ORT_BASE: ORT_BASE, FILES: FILES,
    support: support, cacheInfo: cacheInfo, load: load, unload: unload, clearCache: clearCache, synth: synth,
    isReady: function () { return !!S; },
    sampleRate: function () { return S ? S.cfg.ae.sample_rate : 44100; },
    lastLoadCrashed: function () { var v = ls(LOCK_KEY); if (v) ls(LOCK_KEY, null); return !!v; },
    planChunks: planChunks, finalizeChunk: finalizeChunk, wavBlob: wavBlob,
    _t: { prep: prep, chunk: chunk, splitLong: splitLong, sentences: sentences }
  };
})(typeof window !== 'undefined' ? window : globalThis);
