// Service Worker der Nemea-App. Legt App-Oberfläche, lokale Modell-JSONs und onnxruntime-web in den Cache.
// Die großen ONNX-Modelle (~380 MB) liegen NICHT hier, sondern in Cache Storage "nemea-st3-models-v1"
// (verwaltet von supertonic.js). Dieser Worker fasst fremde Adressen außer onnxruntime-web nie an
// und löscht ausschließlich eigene Caches ("stimmen-reader-*").
// WICHTIG: Alle /proxy/-Anfragen (die vier großen ONNX-Dateien) werden vom App-Shell-Caching
// komplett ausgeschlossen und gehen direkt zum Netzwerk / Cloudflare-Worker-Proxy.
const CACHE = "stimmen-reader-v3";
const ORT = "https://cdn.jsdelivr.net/npm/onnxruntime-web@1.20.1/dist/";
const FILES = [
  "./", "./index.html", "./styles.css", "./app.js", "./supertonic.js",
  "./manifest.webmanifest",
  "./icon-180.png", "./icon-512.png", "./icon-1024.png", "./icon.png",
  "./onnx/tts.json", "./onnx/unicode_indexer.json", "./voice_styles/F1.json"
];
const ORTF = ["ort.min.js", "ort-wasm-simd-threaded.mjs", "ort-wasm-simd-threaded.wasm"].map(f => ORT + f);
// Safari liefert umgeleitete Antworten nicht zuverlässig an Cache-Puts.
const clean = async r => r.redirected ? new Response(await r.blob(), { status: 200, headers: r.headers }) : r;

function isProxyRequest(url) {
  try {
    const u = new URL(url);
    return u.pathname.startsWith("/proxy/");
  } catch (_) {
    return false;
  }
}

self.addEventListener("install", e => e.waitUntil((async () => {
  const c = await caches.open(CACHE);
  for (const u of FILES) {
    try {
      const r = await fetch(u, { cache: "reload" });
      if (r.ok) await c.put(u, await clean(r));
    } catch (_) { }
  }
  for (const u of ORTF) {
    try {
      const r = await fetch(u, { mode: "cors" });
      if (r.ok) await c.put(u, r);
    } catch (_) { }
  }
  self.skipWaiting();
})()));

self.addEventListener("activate", e => e.waitUntil((async () => {
  for (const k of await caches.keys()) if (k.startsWith("stimmen-reader-") && k !== CACHE) await caches.delete(k);
  await self.clients.claim();
})()));

self.addEventListener("fetch", e => {
  const q = e.request;
  if (q.method !== "GET") return;

  // /proxy/* (die vier großen ONNX-Modelle) niemals im Service-Worker-Cache ablegen
  // und auch nicht aus dem App-Shell-Cache bedienen – immer direkt zum Netzwerk/Proxy.
  if (isProxyRequest(q.url)) {
    return; // Browser / Cloudflare Worker übernimmt (kein respondWith)
  }

  const same = new URL(q.url).origin === location.origin, ort = q.url.startsWith(ORT);
  if (!same && !ort) return; // Hugging Face / andere Origins nie anfassen

  e.respondWith((async () => {
    const c = await caches.open(CACHE);
    const hit = await c.match(q, { ignoreVary: true });
    if (hit) return hit;
    try {
      const r = await fetch(q);
      if (r.ok && (r.type === "basic" || r.type === "cors")) c.put(q, r.clone()).catch(() => { });
      return r;
    } catch (err) {
      if (q.mode === "navigate") {
        const s = await c.match("./index.html");
        if (s) return s;
      }
      throw err;
    }
  })());
});
