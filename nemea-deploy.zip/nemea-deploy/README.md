# Nemea – Cloudflare Worker (cold-shadow-315e)

Same-Origin-Streaming-Proxy für die vier Supertonic-ONNX-Modelle + statische App.

**Adresse (bestehend):**  
https://cold-shadow-315e.kealikaruna.workers.dev/

## Inhalt

```
nemea-deploy/                 ← Root-Verzeichnis (enthält wrangler.toml)
├── package.json              # wrangler als gepinnte devDependency
├── wrangler.toml             # name = "cold-shadow-315e"
├── src/
│   └── index.js              # Worker + /proxy/-Streaming-Proxy
├── public/                   # Assets-Verzeichnis (alle App-Dateien)
│   ├── index.html
│   ├── app.js
│   ├── supertonic.js         # DEFAULT_BASE → /proxy/
│   ├── sw.js                 # /proxy/ vom App-Shell-Cache ausgeschlossen
│   ├── styles.css
│   ├── manifest.webmanifest
│   ├── icon-*.png
│   ├── onnx/                 # tts.json, unicode_indexer.json
│   └── voice_styles/         # F1.json
└── README.md
```

Root-Verzeichnis, `wrangler.toml`, Assets-Verzeichnis (`./public`) und Worker-Name
(`cold-shadow-315e`) passen exakt zusammen. Beim Deploy wird der **bestehende** Worker
aktualisiert; alle Dateien unter `public/` werden mitdeployt.

## Voraussetzungen

- Node.js (empfohlen 18+)
- Cloudflare-Account

## Lokaler manueller Deploy

```bash
cd nemea-deploy
npm install                   # installiert die gepinnte wrangler-Version
npx wrangler login            # nur für lokalen manuellen Deploy nötig (einmalig)
npm run deploy                # entspricht: wrangler deploy
```

`wrangler login` wird **nur** für den lokalen manuellen Deploy benötigt.
Bei Cloudflare Workers Builds (GitHub) ist kein `wrangler login` erforderlich;
Cloudflare nutzt die verknüpfte Account-Verbindung.

## Cloudflare Workers Builds + GitHub

1. Dieses Verzeichnis als GitHub-Repository anlegen (oder in ein bestehendes Repo legen).
2. Im Cloudflare Dashboard → **Workers & Pages** → Worker **cold-shadow-315e** öffnen.
3. Reiter **Settings** → **Builds** (bzw. „Connect to Git“).
4. GitHub-Account verbinden und das Repository auswählen.
5. Build-Einstellungen:
   - **Root directory:** Ordner, der `wrangler.toml` enthält (z. B. `/` oder `/nemea-deploy`)
   - **Build command:** `npm install` (installiert die gepinnte wrangler-Version)
   - **Deploy command:** `npx wrangler deploy` (oder `npm run deploy`)
   - Keine weiteren Build-Abhängigkeiten nötig.
6. Speichern. Ab dann löst jeder Push auf den konfigurierten Branch einen Deploy aus.

### iPhone-tauglicher Ablauf (soweit möglich)

- Repository und Cloudflare-Verbindung einmalig an einem Computer einrichten.
- Danach können Änderungen (z. B. über GitHub Mobile) gepusht werden; der Build läuft automatisch auf Cloudflare.
- Die App selbst wird auf dem iPhone unter  
  https://cold-shadow-315e.kealikaruna.workers.dev/  
  getestet (Modelle laden, Sprachausgabe prüfen).

## Proxy-Verhalten (unverändert)

- Nur diese vier Pfade sind erlaubt:
  - `/proxy/onnx/duration_predictor.onnx`
  - `/proxy/onnx/text_encoder.onnx`
  - `/proxy/onnx/vector_estimator.onnx`
  - `/proxy/onnx/vocoder.onnx`
- Fest verdrahtet auf  
  `supertone-oss-archive/supertonic-3` @ `aafc6e32416a594460b32413efc49d7fe4ce6d46`
- GET, HEAD, Range und Content-Range werden durchgereicht
- Response-Body wird gestreamt (kein Puffern)
- Kein offener Proxy

## Hinweise

- Keine Secrets in dieser ZIP enthalten.
- Erster Modell-Download auf dem iPhone benötigt WLAN und freien Speicher (~380 MB).
- Systemstimme bleibt als Fallback verfügbar.
- App-Oberfläche und bestehende Funktionen sind unverändert.
